Dieses Repository wurde im Bezug auf die Leistungsbeurteilung im Modul 259 erstellt. 

Der Datensatz "Did it Rain in Seattle 1948-2017" enthält Wetterdaten für die Stadt Seattle im US-Bundesstaat Washington von 1948 bis 2017. Die Tabelle besteht aus 4 
Spalten: Datum, Niederschlag in Inches, maximale Temperatur in Fahrenheit und minimale Temperatur in Fahrenheit. Die letzte Spalte gibt an, ob es an 
diesem Tag geregnet hat oder nicht. Der Datensatz kann für verschiedene Zwecke genutzt werden, wie zum Beispiel für die Vorhersage von Regen in Seattle basierend auf 
historischen Wetterdaten.

Im folgenden finden Sie einen Link zu diesem Datensatz:
https://www.kaggle.com/datasets/rtatman/did-it-rain-in-seattle-19482017
