In Bezug auf Datenschutzrichtlinien beinhaltet der Datensatz keine persönlichen Informationen 
oder Identifikatoren und wurde unter der Open Database License (ODbL) veröffentlicht. Die ODbL 
erfordert, dass der Urheber der Datenquelle und der Lizenz, unter der sie veröffentlicht wurden, 
zitiert werden müssen. Da der Datensatz öffentlich verfügbar ist, sind keine speziellen Maßnahmen 
zum Schutz der Privatsphäre erforderlich.

Der Urheber dieses Datensatzes ist in diesem Fall Rachel Tachman. Bezogen wurde der Datensatz von "kaggle.com". 

Durch das obige zitieren des Urhebers, der Datenquelle und der Lizenz wurden sämtliche Datenschutzrichtlinien berücksichtigt und somit gewährleistet.
